package com.burgerking.foodpanda.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FoodPandaController {
	
	@RequestMapping("/")
	public ModelAndView getHome()
	{
		return new ModelAndView("index");
	}
	@RequestMapping("/index")
	public ModelAndView Food1()
	{
		return new ModelAndView("index");
	}
	
	@RequestMapping("/preorder")
	public ModelAndView people()
	{
		return new ModelAndView("preorder");
	}
	
	@RequestMapping("/pure")
	public ModelAndView payment()
	{
		return new ModelAndView("pure");
	}
	
	@RequestMapping("/onlinepayment")
	public ModelAndView payment1()
	{
		return new ModelAndView("onlinepayment");
	}
	
	@RequestMapping("/freeorder")
	public ModelAndView payment2()
	{
		return new ModelAndView("freeorder");
	}
	@RequestMapping("/hakka")
	public ModelAndView chi1()
	{
		return new ModelAndView("hakka");
	}
	@RequestMapping("/flavour")
	public ModelAndView chi2()
	{
		return new ModelAndView("flavour");
	}
	@RequestMapping("/discovery")
	public ModelAndView chi3()
	{
		return new ModelAndView("discovery");
	}
	@RequestMapping("/chow")
	public ModelAndView chi4()
	{
		return new ModelAndView("chow");
	}
	@RequestMapping("/box8")
	public ModelAndView fast1()
	{
		return new ModelAndView("box8");
	}
	@RequestMapping("/donalds")
	public ModelAndView fast2()
	{
		return new ModelAndView("donalds");
	}
	@RequestMapping("/kfc")
	public ModelAndView fast3()
	{
		return new ModelAndView("kfc");
	}
	@RequestMapping("/dominoz")
	public ModelAndView fast4()
	{
		return new ModelAndView("dominoz");
	}
	@RequestMapping("/nescafe")
	public ModelAndView healthy1()
	{
		return new ModelAndView("nescafe");
	}
	@RequestMapping("/subway")
	public ModelAndView healthy2()
	{
		return new ModelAndView("subway");
	}
	@RequestMapping("/product")
	public ModelAndView pro2()
	{
		return new ModelAndView("product");
	}
	
}
