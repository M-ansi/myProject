package com.burgerking.foodpanda.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bugerking.foodpanda.dao.ProductDAO;
import com.bugerking.foodpanda.dao.ProductDAOImpl;
import com.bugerking.foodpanda.service.CategoryService;
import com.bugerking.foodpanda.service.ProductService;
import com.burgerking.foodpanda.model.Category;
import com.burgerking.foodpanda.model.Product;

@Controller
public class ProductController<CategoryBean> {

@Autowired	(required=true)
private ProductService productService;

@Autowired
private CategoryService categoryService;
	
	
	
	

	@RequestMapping(value = "/products", method = RequestMethod.GET)
	public String listCategorys(Model model) {
		model.addAttribute("product", new Product());
		model.addAttribute("category",new Category());
		model.addAttribute("productList", this.productService.list());
		return "product";
	}
	
	public ProductService getProductService() {
		return productService;
	}

	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

		//For add and update category both
		@RequestMapping(value= "/product/add", method = RequestMethod.POST)
		public String addProduct(@ModelAttribute("product") Product product){
			
			Category category = categoryService.getByName(product.getCategory().getName());
			categoryService.saveOrUpdate(category);  // why to save??
				
				product.setCategory(category);
				product.setCategory_id(category.getId());
				productService.saveOrUpdate(product);
			return "redirect:/products";
			
		}
		@RequestMapping("product/remove/{id}")
	    public String removeProduct(@PathVariable("id") String id,ModelMap model) throws Exception{
			
	       try {
			productService.delete(id);
			model.addAttribute("message","Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message",e.getMessage());
			e.printStackTrace();
		}
	       //redirectAttrs.addFlashAttribute(arg0, arg1)
	        return "redirect:/products";
	    }
	 
	    @RequestMapping("product/edit/{id}")
	    public String editCategory(@PathVariable("id") String id, Model model){
	    	System.out.println("editProduct");
	        model.addAttribute("product", this.productService.get(id));
	        model.addAttribute("listProducts", this.productService.list());
	        return "product";
	    }
	    
}
