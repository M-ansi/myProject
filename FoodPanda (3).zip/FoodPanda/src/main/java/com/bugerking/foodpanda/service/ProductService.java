package com.bugerking.foodpanda.service;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bugerking.foodpanda.dao.ProductDAOImpl;
import com.burgerking.foodpanda.model.Product;

@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDAOImpl productDAO;
	
	public List<Product> list() {
		return productDAO.list();
	}
	public void saveOrUpdate(Product product){
		productDAO.saveOrUpdate(product);
		
	}
	
	public void delete(String id){
		productDAO.delete(id);
	}
	public Product get(String id){
		return productDAO.get(id);
	}
	

}
